.. _faq:

F.A.Q
=====

*Any encoding issue ?*

Try to run Glances with the following command line:

    LANG=en_US.UTF-8 LC_ALL= glances
