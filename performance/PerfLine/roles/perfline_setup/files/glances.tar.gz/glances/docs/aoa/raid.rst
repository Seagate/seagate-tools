.. _raid:

RAID
====

*Availability: Linux*

*Dependency: this plugin uses the optional pymdstat Python lib*

This plugin is disable by default, please use the --enable-plugin raid option
to enable it.

In the terminal interface, click on ``R`` to enable/disable it.

.. image:: ../_static/raid.png

This plugin is only available on GNU/Linux.
