#### Description

Please describe the goal of this pull request.

For any questions concerning installation or use, please open a discussion (https://github.com/nicolargo/glances/discussions), not an issue.

#### Resume

* Bug fix: yes/no
* New feature: yes/no
* Fixed tickets: comma-separated list of tickets fixed by the PR, if any
