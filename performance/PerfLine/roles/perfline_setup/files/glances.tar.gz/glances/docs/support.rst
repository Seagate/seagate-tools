.. _support:

Support
=======

To post a question about Glances use cases, please post it to the
official Q&A `forum
<https://groups.google.com/forum/?hl=en#!forum/glances-users>`_.

To report a bug or a feature request use the GitHub `issue
<https://github.com/nicolargo/glances/issues>`_ tracker.

Feel free to contribute!
